package com.example.javafx;

public class dashboardcontroller {
    
}
